
import Foundation

print("Вычисление площади, периметра и гипотянузы треугольника: ")

//вводные данные
let a = 5
let b = 6

//формула
var per = (a * a + b * b)
var sqr = (a + b) / 2

                        //var gip = math.sqrt(a * a) + (b * b)
                        //var gip = sqrt((a * a) + (b * b))
                        //var gip = √((a * a) + (b * b))

//Вывод
print("Периметр треугольника равен: \(per)")
print("Площадь треугольника равна: \(sqr)")

                        //print("Гипотянуза треугольника равна: \(gip)")

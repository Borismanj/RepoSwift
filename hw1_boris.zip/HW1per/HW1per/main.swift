
import Foundation

print("Вычисление процентов через 5лет")

//Вводные данные
let depo = 100000
let perc = 8

//Формула
var sum = depo * perc

//Вывод
print("Сумма депозита составит: \(sum)")
